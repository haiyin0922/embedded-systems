#include <msp430.h>
#define LED1 BIT0
#define LED2 BIT6
#define B1 BIT3

int main(void) {
   WDTCTL = WDTPW | WDTHOLD;
   P1DIR |= LED1 + LED2;
   P1REN |= B1;
   P1OUT |= B1;

   volatile unsigned int cnt = 0, flag = 0;
   for(;;) {
      volatile unsigned int i;
      if((P1IN & B1) == 0){
          cnt = 0;
          if(flag == 0){
              P1OUT &= ~(LED1 + LED2);
              flag = 1;
          }
          else{
              P1OUT ^= LED1 + LED2;
          }
      }
      else{
          flag = 0;
          cnt++;
          if(cnt == 6){
              P1OUT &= ~(LED1 + LED2);
              cnt = 0;
          }
          else if(cnt == 5){
              P1OUT &= ~LED1;
              P1OUT ^= LED2;
          }
          else{
              P1OUT &= ~LED2;
              P1OUT ^= LED1;
          }
      }

      i = 20000;
      do i--;
      while(i != 0);
   }
   return 0;
}
